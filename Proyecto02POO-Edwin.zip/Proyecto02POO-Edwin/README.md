# Proyecto02POO
Es el segundo proyecto de Programación Orientada a Objetos.
# Fase 2
ESTRUCTURA

1. Partes de escritura

La parte escrita de la fase 2 se encuentra en este archivo de drive: https://docs.google.com/document/d/1t13qmhHgoDOmiYz1dxG-A4k0PWhoQbs0/edit?usp=sharing&ouid=114812859543522488485&rtpof=true&sd=true

Asi mismo la parte de lista de actividades hecha se encuentra en este archivo de drive: https://docs.google.com/spreadsheets/d/1QjPZ1WLqKvW8uxFHnlZvUBU0XBiXmgMcuwO728PgdaM/edit?usp=sharing

2. Estructuración del github

Branch Main: es donde se encuentra el trabajo principal y en sí la palicación final.

Branch Diego es donde trabaja Diego Andrés Alonzo Medinilla carné 20172 su parte, él se encarga de toda la parte de matrices y modelado de ciudades.

Branch Edwin es donde trabaja Edwin.

